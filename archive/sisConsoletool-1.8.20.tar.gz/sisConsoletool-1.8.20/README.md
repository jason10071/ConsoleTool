Requirement
---
    1. Linux x86 or x86_64 platform
    2. Java
        * JDK 6 (JRE alone is not sufficient)
        * Apache Ant 1.8 or later
    3. Android Developer Tool Kit (http://developer.android.com/sdk/index.html)
        * SDK
        * NDK
        * eclipse (optional)

Compilation
---
    Just type 'make' on the root directory os this projecct
    $ make
