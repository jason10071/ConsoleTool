#!bin/sh

# consoletool path
CONSOLETOOL=consoletool
GET_FIRMWARE_ID=${CONSOLETOOL}/getFirmwareId
UPDATE_FW=${CONSOLETOOL}/updateFW

# fwbin path
FW_BIN_DIR=fwbin 
BIN_MASTER=${FW_BIN_DIR}/dump_fw_M.bin
COMPARE_MASTER="-f=${BIN_MASTER}"

FLAGS_FALSE=false
FLAGE_TRUE=true
update_needed=${FLAGE_FALSE}
check_is_update_needed() {
	echo "\nCheck is update needed"
	${GET_FIRMWARE_ID} ${COMPARE_MASTER}
	ret=$?

	if [ ${ret} -eq 0 ]; then
		# Firmware Id is the same
		echo "\nFirmware check done: already latest version"
                update_needed=${FLAGS_FALSE}
	elif [ ${ret} -eq 33 ]; then
		# Firmware Id is diffrtrnt
		echo "\nFirmware check done: update needed"
                update_needed=${FLAGS_TRUE}
	else
		# compare error occur
		echo "\nFirmware check done: compare error occur"
                update_needed=${FLAGS_FALSE}
	fi
}

update_firmware() {
	echo "Update firmware"
	${UPDATE_FW} -ba ${BIN_MASTER}
}

main() {
	check_is_update_needed

        if [ "${update_needed}" = "${FLAGS_TRUE}" ]; then
		update_firmware
        fi
}

main

